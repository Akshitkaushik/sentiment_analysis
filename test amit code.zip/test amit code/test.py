from db_name import db_name_check
from datetime import datetime,timedelta

db=db_name_check.DB_MSSQL(None)
from lib.send_email_new import SendMail
from lib.manageSession import manageUserHistory as manageUser
from lib import convertDate
import requests

# import ipdb
# ipdb.set_trace()
# print(convertDate.deleteDigitFromUserId("+918178947796"))

# send_token_to_employee_phone = """http://197.232.64.206/roberms/smsapi/?apisend=yes&key=65B9EEA6E1CC6BB9F0CD2A47751A186F&msisdn={0}&textMessage=OTP for Aria Is {1}""".format('+'+str(918178947796), "12323")
#
# result = requests.get(send_token_to_employee_phone)
# print(send_token_to_employee_phone)
# print(result)
# print(result.status_code)

# import ipdb
# ipdb.set_trace()
# message = '04/2020'
# date=datetime.strptime(datetime.strftime(datetime.now() - timedelta(1),'%m/%Y'),'%m/%Y')
# date_previous = datetime.strptime(datetime.strftime(datetime.now() - timedelta(365), '%m/%Y'),'%m/%Y')
# message1 = datetime.strptime(message, '%m/%Y')
# if date_previous>=message1 or date<=message1:
#     messages=["Sorry, I am not able to process the request. Kindly the contact HR."]


# import whatsapp_run as whatsapp_runObj
# whatsapp_runObj.starting_messages("918178947796@c.us","arvind")
# whatsapp_runObj.main_menu("918178947796@c.us")

# output = whatsapp_runObj.identifyClass("2","918178947796@c.us")
# print(output)
# output = whatsapp_runObj.HandleClassBroadCast("hello how are you","918178947796@c.us")
# print(output)


# email_obj_new = SendMail()
#
# email_obj_new.sendToken('arvindkumar6568@gmail.com',"98766")
#


# print(result)
# import  os
# import shutil
#
# local_path = os.path.abspath(os.path.curdir)
# destination_path = os.path.join(local_path,"TempAttachment")
#
#
# file_name='abcd.html'
# file_path = os.path.join(local_path, file_name)
#
#
# all_htm='aaaaaa'
# Html_file_name = open(file_name, "w")
# Html_file_name.write(all_htm)
# Html_file_name.close()
#
import email, smtplib, ssl

from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.message import EmailMessage


# email_list=[ALKANE.PATEL@BIDCOAFRICA.COM, RAKHI.HARIYA@BIDCOAFRICA.COM, abhik.dasgupta@in2ittech.com,amit.malik@in2ittech.com]
recipients='abhik.dasgupta@in2ittech.com','amit.malik@in2ittech.com'



# def sendTask(self, email, data):
#     msg = EmailMessage()
#
#     server = smtplib.SMTP('outlook.office365.com', 587)
#     server.ehlo()
#     server.starttls()
#     server.login("rpa@bidco-oil.com", 'Bot123#')
#     text='wewe'
#     # if(re.search( email)):
#     # for i in range
#     # to = email[0]
#     # cc = email[1]
#     # to =email_list
#     msg = MIMEMultipart('alternative')
#     msg['Subject'] = 'xyz'
#     msg['To'] = recipients
#     # msg['Cc'] = cc
#     # body = data
#
#     msg.attach(MIMEText(body, 'plain'))
#     # server.send_message(msg, from_addr='rpa@bidco-oil.com', to_addrs=None)
#     server.sendmail('rpa@bidco-oil.com', recipients.split(','), text.as_string())
#     # s.sendmail(sender, recipients.split(','), msg.as_string())
#     server.quit()
# data='sasas'
# def sendTask(data):
#         msg = EmailMessage()
#
#         server = smtplib.SMTP('outlook.office365.com', 587)
#         server.ehlo()
#         server.starttls()
#         server.login("rpa@bidco-oil.com", 'Bot123#')
#         # if(re.search( email)):
#
#         msg = MIMEMultipart('alternative')
#         msg['Subject'] = 'Task Allocation'
#         msg['To'] = 'abhik.dasgupta@in2ittech.com','amit.malik@in2ittech.com'
#         # msg['Cc'] = cc/
#         body = 'sdsfdf'
#
#         msg.attach(MIMEText(body, 'plain'))
#         server.send_message(msg, from_addr='rpa@bidco-oil.com', to_addrs=None)
#         server.quit()
# sendTask('wsds')




# local_path = os.path.abspath(os.path.curdir)
# destination_path = os.path.join(local_path,"TempAttachment")
#
#
# file_name='abcd.html'
# file_path = os.path.join(local_path, file_name)
#
#
# all_htm='aaaaaa'
# Html_file_name = open(file_name, "w")
# Html_file_name.write(all_htm)
# Html_file_name.close()
#
#
# shutil.move(file_path, destination_path)












# shutil.move(file_path, destination_path)
#
# x=db.manager_info('12')
# print(x)
#
# # with open(Html_file) as f:
#     text = f.read()
# f.close()
# # shutil.move(file_name, local_path + "\\TempAttachment\\" + file_name)
# try:
#     shutil.move(file_name, local_path + "\\TempAttachment\\" + file_name)
# finally:
#     shutil.move(Html_file, local_path + "\\TempAttachment\\" + Html_file)


# from lib.schedulerForBidco import SchedulerForLeaveApprove
# #
# schedulerForLeaveApproveClassObject = SchedulerForLeaveApprove()
# #
# # schedulerForLeaveApproveClassObject.updateLeaveStatus()
# schedulerForLeaveApproveClassObject.updateLeaveStatus()
# schedulerForLeaveApproveClassObject.sendExcelFileAfter48Hours()
# print("hello")

# while True:
#     a =2

# import asure_bucket
# print(asure_bucket.ghi())
#
# result=db.getAllemployeeMobileNumber('BCAL',False)
# print(result)

# import datetime
# data = [('3057','2020-02-15',str(datetime.datetime(2020, 2, 14, 22, 54, 0, 417000))[0:23])]
# print(data)
# result=db.attendance_THREE_month('8178947796','12')
# print(result)

# print(seconManagerInfo is not None and seconManagerInfo != [] and (seconManagerInfo[0][0] is None or seconManagerInfo[0][4] is None or seconManagerInfo[0][5] is None))
# def change_date(date):
#     try:
#         date = datetime.strptime(date, '%d.%m.%Y')
#         new_date = date.strftime('%d.%m.%Y')
#         return new_date
#     except:
#         return ""

# result=db.checkAndSendExcelFileStatusAfter48Hours()
# if "sendExcelFile" in result[0].keys():
#     result[0]["sendExcelFile"]="True"
# print(result[0])



# result = db.getAllemployeeMobileNumber()
# print(result)


# email_obj_new.createExcelShhetForUserHistory(**result)


# result=objectOfManageSession.manageSessionForAllEmployess('12','2020-01-15 07:48:26.950')
# print(result)
# print(str(result['lastActionDateTime'])[0:23])


# result=objectOfManageSession.manageUserHistory('process1','12','2020-01-15 07:48:26.950','')
# print(result)

# import schedule
# import time
# from db_name import db_name_check
# db = db_name_check.DB_MSSQL(None)
# from datetime import datetime,timedelta
#
# def job():
#     print("I'm working...")
#     currentDateTime = datetime.now().date()
#
#     yesterDayDateTime = (datetime.now() - timedelta(days=1)).date()
#     # fix the datetime 2020-1-15 00:00:00"
#
#     lastDateTime = str(yesterDayDateTime) + " " + "06:01:00"
#     nextDateTime = str(currentDateTime) + " " + "18:00:00"
#
#     lastTime = datetime.strptime(lastDateTime, '%Y-%m-%d %H:%M:%S')
#     nextTime = datetime.strptime(nextDateTime, '%Y-%m-%d %H:%M:%S')
#     print(lastTime, nextTime)
#     obj = db.getUserHistory(lastTime, nextTime)
#     print('hello')
#     print(obj)
#     email_obj_new.createExcelSheetForUserHistory(**obj)
#
# schedule.every().day.at("18:19").do(job)
# while True:   #while run will be run continously and after 5 seconds job method call automatically
#     schedule.run_pending()









# print(len(result[1]))
#
# fetch_employe_leave_after_insert_leave = db.Fetch_to_manager_specific_leaves('12', '2019-11-22', '2019-11-22','13')
# print('fetch_employe_leave_after_insert_leave')
# print(fetch_employe_leave_after_insert_leave[0][0])
#
# nextUser=db.getNextUserForApproveTheLave('13')
# print(nextUser)
# # print (nextUser[0])
# # print(nextUser[1][0])
# # print(nextUser[1][0]['name'])
#
#
# # print(result[0])
# # print(result[1])
# # print(result[0][1])
# # print(result[1][1])
# #
# # result.sort(key=lambda L: datetime.strptime(L[2], '%Y-%m-%d'))
# #
# # print(result)
# # print(result[0][1])
# # print(result[1][1])
#
# import os
# filename, file_extension = os.path.splitext('/path/to/somefile.ext')
# print(filename)
# print(file_extension)



# result = db.getGuidNo('12','2019-12-18')
# print(result)
# print(result[0])
# print(result[0][0])

# leave_desc = db.get_full_pay_sick_leave('1111111111','12')
# print(leave_desc)
#
# obj = {"id":1,"name":2}
# print(len(obj.keys()))
# messages  = ""
# result = ""
# if leave_desc != None:
#     for i in range(0,len(leave_desc.keys())):
#         print(list(leave_desc.keys())[i])
#         leaveType = str((list(leave_desc.keys())[i])).replace('%'," ").strip()
#
#         result  = result +  leaveType +' : '+str(list(leave_desc.values())[i])+" "
#
# print(result)

# leave_desc = db.checkLeaveDateExistInHoliday('2019-11-11','2019-11-11')
# print(leave_desc)


# result = db.gerHREmailFromPers('12')
# print(result)

result = db.personInfo('12')
print(result)

print("################################################")
# result = db.all_month_leaves_taken_get_used_leave_from_leave_table("918178947796")
# print(result)
#
# result = db.my_info('1')
# print(result)
#
#
# result = db.getAppliedOnOfLeave('2','2020-09-24')
# print(result)
#
#
# result = db.Fetch_to_manager_specific_leaves('2','2020-10-06','2020-10-15','1')
#
# print(result)
#
# result = db.getNextUserForApproveTheLave('1',"False")
# print(result)
#
# result = db.fetchAllEmployessAplliedLeaveLastFiveDays('1')
# print(result)
#
#
# # result = db.updateAppliedOnInAllocateTaskTable('2020-10-14 11:36:58.540','2020-10-15','2')
# # print(result)
#
# result = db.deleteTaskFromAllocateTask('2020-10-15','2')
# print(str(result))


result = db.Fetch_to_manager_specific_leaves('2', '2021-03-22', '2021-03-30', '1')
print(result)

# from lib import checkStartDate
# result = checkStartDate.isValidStartDate('2/1/2021',-1)
# print(str(result))

# from lib import abc
# obj={"id":1}
# abc.tt(obj)
# print("obj ",obj)

# result = db.getNextUserForApproveTheLave('1','True')
# print(result)

# currentDate = str(datetime.now().date())
# result = db.checkManagerOnLeaveOrNot(currentDate,'16')
# print(result)
#
# email_obj_new.createExcelFileForHRForBoTStatusFailLeave(result)

# from bidco_apis1_excel.schedulerForAttendance.index import AttendenceScheduler
#
# obj = AttendenceScheduler()
# result = obj.attedance()
# print(result)


# obj = ["leaveType","pers_No","appliedOn","startDate","endDate","totalLeaves","reason","guid","botStatus","hrStatus"]
#
#
# # import openpyxl module
# import openpyxl
# from openpyxl.worksheet.datavalidation import DataValidation
#
# # Call a Workbook() function of openpyxl
# # to create a new blank Workbook object
# wb = openpyxl.Workbook()
#
# # Get workbook active sheet
# # from the active attribute
# sheet = wb.active
#
# rowIndex = 1
# columnIndex = 1
# columnCell = []
# i = 0
# # import ipdb
# # ipdb.set_trace()
# for column in obj:
#     columnCell = sheet.cell(row=rowIndex, column=columnIndex)
#     columnCell.value = column
#     columnIndex += 1
#     i += 1
#
#
# if result != []:
#     for record in result:
#         rowIndex += 1
#         # print(record)
#         # leaveType = str(record[0]).replace("%", " ").strip() if record[0] is not None and str(record[0]) != "" else ""
#         # pers_No = str(record[1]).replace("%", " ").strip() if record[1] is not None and str(record[1]) != "" else ""
#         # appliedOn = str(record[2]) if record[2] is not None and str(
#         #     record[2]) != "" else ""
#         # startDate = str(record[3]) if record[3] is not None and str(
#         #     record[3]) != "" else ""
#         # endDate = str(record[4]) if record[4] is not None and str(
#         #     record[4]) != "" else ""
#         # totalLeaves = str(record[5]) if record[5] is not None and str(
#         #     record[5]) != "" else ""
#         # reason = str(record[6]) if record[6] is not None and str(
#         #     record[6]) != "" else ""
#         # guid = str(record[7]) if record[7] is not None and str(
#         #     record[7]) != "" else ""
#         # botStatus = str(record[8]) if record[8] is not None and str(
#         #     record[8]) != "" else ""
#         # import ipdb
#         # ipdb.set_trace()
#         for index in range(len(obj)):
#             columnCellObject = sheet.cell(row = rowIndex,column = index+1) #because row and column start from 1
#             if index == 0:
#                 columnCellObject.value = str(record[0]).replace("%", " ").strip() if record[0] is not None and str(record[0]) != "" else ""
#             elif index == 1:
#                 columnCellObject.value = str(record[1]).replace("%", " ").strip() if record[1] is not None and str(record[1]) != "" else ""
#             elif index == 2:
#                 columnCellObject.value = str(record[2]) if record[2] is not None and str(record[2]) != "" else ""
#             elif index == 3:
#                 columnCellObject.value = str(record[3]) if record[3] is not None and str(record[3]) != "" else ""
#             elif index == 4:
#                 columnCellObject.value = str(record[4]) if record[4] is not None and str(record[4]) != "" else ""
#             elif index == 5:
#                 columnCellObject.value = str(record[5]) if record[5] is not None and str(record[5]) != "" else ""
#             elif index == 6:
#                 columnCellObject.value = str(record[6]) if record[6] is not None and str(record[6]) != "" else ""
#             elif index == 7:
#                 columnCellObject.value = str(record[7]) if record[7] is not None and str(record[7]) != "" else ""
#             elif index == 8:
#                 columnCellObject.value = str(record[8]) if record[8] is not None and str(record[8]) != "" else ""
#
#
#
#
#
# # for number in range(1,100): #Generates 99 "ip" address in the Column A;
# #     ws['A{}'.format(number)].value= "192.168.1.{}".format(number)
#
# data_val = DataValidation(type="list",formula1='"TRUE,FALSE"') #You can change =$A:$A with a smaller range like =A1:A9
# sheet.add_data_validation(data_val)
#
# data_val.add(sheet["J2"])
# cellValue = sheet["J2"] #it is for set default value of J2
# cellValue.value = 'False'
#
# wb.save("demo.xlsx")

import os
# from lib.send_email_new import SendMail
# from multiprocessing import Process,Pool
# email_obj_new = SendMail()
#
# def abc():
#     leaveObject = db.getGuidNo('12', '2019-12-18' )
#     data = {'type': "history of leave applied",
#         'persdetail': leaveObject}
#     fileName = email_obj_new.createExcelSheet(**data)
#     print(fileName)
#     email_obj_new.sendMessage('excel',fileName)
#     local_path = os.path.abspath(os.path.curdir)
#     filepath = local_path + "\\sendExcel\\" + fileName
#     os.remove(filepath)
#     print('hello')
#
# def defg():
#     print('you are in defg')
#     leaveObject = db.getNextUserForApproveTheLave('12','')
#     print((leaveObject))
#     print("jhgfdsdfghj")
# if __name__ == "__main__":
#     proc = Process(target=abc)
#     proc.start()
#     # proc.join()
#     print('execute next line')
#     defg()



# local_path = os.path.abspath(os.path.curdir)
# path_image = local_path + '\\MedicalImage\\' + '12_01-01-2020 21-14-33.jpe'
# os.remove(path_image)



# print("hello")
# abc = "2016-04-04"
# print(datetime.strptime(abc,'%Y-%m-%d').strftime('%d/%b/%Y'))
# import re
#
# regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
#
#
#
#
# if (re.search(regex, 'arvindkumar6568@gmaicom')):
#     print("Valid Email")
#
# else:
#     print("Invalid Email")

# print(type(str(datetime.strptime('12/12/2019','%d/%m/%Y').year)))
# if result[0] == str(datetime.strptime('12/12/2019','%d/%m/%Y').year):
#     print("hello")

# print(datetime.strptime(datetime.strptime('10/11/2019', '%d/%m/%Y').strftime('%Y-%m-%d'),'%Y-%m-%d').date()
# < (datetime.now()- timedelta(days=180)).date())

# from lib.send_email_new import SendMail
# email_obj_new = SendMail()
# data = {"id":1,"name":"arvind"}
# print(email_obj_new.createExcelSheet(**data))
#
# print((datetime.now().strftime('%d-%m-%Y %H-%M-%S'))[0:23])

# import os
# os.remove('D:\\amit_bidco_25_12_2019\\Bidco Whatsapp\\Bidco Whatsapp\\sendExcel\\persDetail25-12-2019 14-17.xlsx')

# import os
# # cwd = os.getcwd()
# # print(os)
# local_path=os.path.abspath(os.path.curdir)
# print(local_path)

# print(type(result[4]))
# if result[4]==None or result[4]=='':
#     print("hello")
#
# if result[5]=='True':
#     print("hbfhfb")


# def upload_data_to_table(self, **data):
#     table_name = data['table_name']
#     column_names = data['column_name']
#     values = data['values']
#     if table_name == 'Attendance':
#         table_name = 'AttendanceDataBackupTest'
#
#     query = "INSERT INTO [dbo].{0} {1} VALUES {2}".format(table_name, column_names, values)
#     print (query)
#     Cursor = self.cursor.execute(query)
#     Cursor.commit()
#     return True

