# CATEGORY = {"1": "inquiry",
#            "2": "hardware",
#            "3": "database",
#            "4": "network",
#            "5": "software"}
#
# SUBCATEGORY = {"inquiry": {"1": "antivirus",
#                           "2": "email",
#                           "3": "internal application"},
#                'hardware': {"1": "cpu",
#                             "2": "disk",
#                             "3": "keyboard",
#                             "4": "memory",
#                             "5": "monitor"},
#                'database': {"1": "db2",
#                            "2": "sql server",
#                            "3": "oracle"},
#                'network': {"1": "dhcp",
#                           "2": "dns",
#                           "3": "ip address",
#                           "4": "vpn",
#                           "5": "wireless"},
#                'software': {"1": "email",
#                            "2": "os"}
#                }
#
# BUSINESS_SERVICE = {"1": "Neo broadband",
#                    "2": "Neo internet",
#                    "3": "Neo metro",
#                    "4": "Neo voice",
#                    "5": "Neo carrier"}
#
# CI = {"1": "027JOHA1252011241079",
#      "2": "027GEOR1252012042198",
#      "3": "027CAPE1252012304739",
#      "4": "027JOHA361010714528",
#      "5": "027CAPE680010855434",
#      "6": "027PRET2360011856950"}