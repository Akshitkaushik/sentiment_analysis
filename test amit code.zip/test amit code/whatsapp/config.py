

DB_CONN_STR = 'Driver={SQL Server};Server=WhatsApp-BOT;Database=Bidco2;uid=sa;pwd=bidco@123;Trusted_Connection=no;'