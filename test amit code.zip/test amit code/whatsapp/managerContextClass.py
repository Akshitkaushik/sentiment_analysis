class ManagerContext:
    def __init__(self):
        self.identifyClass=None
        self.lastEmployeeRequestForLeaveDict=None
        self.setAllEmployeeRequestForLeaveDict=None
        self.message = None
        self.higherManager = None

        #####add by Arvind 13/jan/2020#####
        self.managerHistoryObjectDic = None

        #####add by Arvind 14/jan/2020#####
        self.setUserObject = None

        #####add by Arvind 16/feb/2020#####
        self.setPreviousMenu = False #when manager select 5th option in leave applied then it will show to manager

    def setIdentifyClass(self,className):
        self.identifyClass=className

    def getIdentifyClass(self):
        return  self.identifyClass

    def setLastEmployeeRequestForLeave(self, lastEmployeeRequestForLeaveDict):
        self.lastEmployeeRequestForLeaveDict = lastEmployeeRequestForLeaveDict

    def getLastEmployeeRequestForLeave(self):
        return self.lastEmployeeRequestForLeaveDict

    def setAllEmployeeRequestForLeave(self,allEmployee):
        self.setAllEmployeeRequestForLeaveDict=allEmployee

    def getAllEmployeeRequestForLeave(self):
        return self.setAllEmployeeRequestForLeaveDict

    def setMessage(self,message):
        self.message = message

    def getMessage(self):
        return self.message

    def setHigherManagerStatus(self,higherManager):
        self.higherManager = higherManager

    def getHigherManagerStatus(self):
        return  self.higherManager

    #######add by Arvind 13/jan/2020#######
    def setManagerHistoryObjectDic(self, data):
        self.managerHistoryObjectDic = data

    def getManagerHistoryObjectDic(self):
        return self.managerHistoryObjectDic

    def setUserOrManagerObject(self, data):
        self.setUserObject = data

    def getUserOrManagerObject(self):
        return self.setUserObject

    def setPreviousMenuForManager(self,data):
        self.setPreviousMenu = data

    def getPreviousMenuForManager(self):
        return self.setPreviousMenu