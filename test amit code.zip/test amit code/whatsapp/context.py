


class Context:
    def __init__(self):
        self.subject = None
        self.description = None
        self.ticket_type = None
        self.category = None
        self.sysId = None
        self.comment = None
        self.ticket_type_data = None
        self.category_data = None

        self.days = None
        self.date = None
        self.reason=None

        self.leave_type=None

        self.StartDate=None
        self.EndDate=None
        self.Task=None
        self.Allocate=None
        self.Allowance=None

        self.approved_user = None

        self.cancel_leaves=None
        self.download_medical_report = False


        #################Arvind start work###############
        self.remainingLeaveOfLeaveType = None
        self.setLeaveTypeInDic = None
        self.fileName = None

        self.TotalLeave=None
        self.yesOrNo = None
        self.userHistoryObjectDic = None
        self.broadCastMsg = None

        #it is used when leave more tahn 7 days but task not ask(because leave endDate comes before current Date)
        self.attachmentWhenTaskNotAsk = False


        #################Arvind end work#################



    def setSubject(self,subject):
        self.subject=subject

    def getSubject(self):
        return self.subject

    def setTotalLeave(self,TotalLeave):
        self.TotalLeave=TotalLeave

    def getTotalLeave(self):
        return self.TotalLeave



    def setDescription(self,description):
        self.description = description

    def getDescription(self):
        return self.description

    def setTicketType(self, ticket_type):
        self.ticket_type = ticket_type

    def getTicketType(self):
        return self.ticket_type

    def setCategory(self, category):
        self.category = category

    def getCategory(self):
        return self.category

    def setTicketTypeData(self, ticket_type_data):
        self.ticket_type_data = ticket_type_data

    def getTicketTypeData(self):
        return self.ticket_type_data

    def setCategoryData(self, category_data):
        self.category_data = category_data

    def getCategoryData(self):
        return self.category_data

    def setSysId(self,sysId):
        self.sysId = sysId

    def getSysId(self):
        return self.sysId

    def setComment(self,comment):
        self.comment = comment

    def getComment(self):
        return self.comment

    ########################################## BIDCO CONTEXT NEW #######################################################

    def setDate(self,date):
        self.date = date

    def getDate(self):
        return self.date

    def setDays(self,days):
        self.days = days

    def getDays(self):
        return self.days


    def setReason(self,reason):
        self.reason = reason

    def getReason(self):
        return self.reason



    def setLeave_Type(self,leave_type):
        self.leave_type = leave_type

    def getLeave_Type(self):
        return self.leave_type

    def setStartDate(self,StartDate):
        self.StartDate = StartDate

    def getStartDate(self):
        return self.StartDate

    def setEndDate(self,EndDate):
        self.EndDate = EndDate

    def getEndDate(self):
        return self.EndDate

    def setTask(self,Task):
        self.Task = Task

    def getTask(self):
        return self.Task

    def setAllocate(self,Allocate):
        self.Allocate = Allocate

    def getAllocate(self):
        return self.Allocate

    def setAllowance(self,Allowance):
        self.Allowance = Allowance

    def getAllowance(self):
        return self.Allowance

    def setApproveduser(self,approved_user):
        self.approved_user = approved_user

    def getApproveduser(self):
        return self.approved_user


    ##################Arvind start work########################
    def setRemainingLeaveOfLeaveType(self,remainLeaves):
        self.remainingLeaveOfLeaveType=remainLeaves

    def getRemainingLeaveOfLeaveType(self):
        return self.remainingLeaveOfLeaveType

    ##################Arvind end work########################


    def setCancel_Leaves(self,cancel_leaves):
        self.cancel_leaves = cancel_leaves

    def getCancel_Leaves(self):
        return self.cancel_leaves


    def setdownload_medical_report(self,download_medical_report):
        self.download_medical_report = download_medical_report

    def getdownload_medical_report(self):
        return self.download_medical_report

    def setLeaveTypeInDictionary(self,leavesDic):
        self.setLeaveTypeInDic = leavesDic

    def getLeaveTypeInDictionary(self):
        return self.setLeaveTypeInDic

    def setFileName(self,fileName):
        self.fileName = fileName

    def getFileName(self):
        return self.fileName

    def setYesOrNoForMoreTaskAllocate(self,data):
        self.yesOrNo = data

    def getYesOrNoForMoreTaskAllocate(self):
        return  self.yesOrNo

    #######add by Arvind 13/jan/2020#######
    def setUserHistoryObjectDic(self,data):
        self.userHistoryObjectDic = data

    def getUserHistoryObjectDic(self):
        return self.userHistoryObjectDic

    def setBroadCastMsg(self,data):
        self.broadCastMsg = data

    def getBroadCastMsg(self):
        return self.broadCastMsg

    def setAttachmentWhenTaskNotAsk(self,value):
        self.attachmentWhenTaskNotAsk = value

    def getAttachmentWhenTaskNotAsk(self):
        return self.attachmentWhenTaskNotAsk