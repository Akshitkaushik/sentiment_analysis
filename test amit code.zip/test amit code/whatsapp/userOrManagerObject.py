


class UserOrManagerObj:
    def __init__(self):
        #################Arvind start work###############
        self.setUserObject = None
        #################Arvind end work#################

    def setUserOrManagerObject(self,data):
        self.setUserObject = data

    def getUserOrManagerObject(self):
        return self.setUserObject