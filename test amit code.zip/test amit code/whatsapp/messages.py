ENTER_TOKEN = "Please enter the OTP received via SMS/Email."

BOT_INTRO = "My name is Aria, how may I help you?"
INITIAL_MESS = "Please select from one of the options from below, only type the number"

# INITIAL_OPTIONS = "1. My Info\n" \
#                "2. Leave Management\n" \
#                "3. Attendance Management\n" \
#                "4. Payroll Management\n" \
#                "5. Exit\n" \

INITIAL_OPTIONS_ACCORDING_PAREA = "1. My Info\n" \
               "2. Leave Management\n" \
               "3. Attendance Management\n" \
               "4. Payroll Management\n" \
               "5. Exit\n" \

INITIAL_OPTIONS_ACCORDING_PAREA_BROADCAST = "1. My Info\n" \
               "2. Leave Management\n" \
               "3. Attendance Management\n" \
               "4. Payroll Management\n" \
               "5. Broadcast message over WhatsApp\n"\
               "6. Exit\n" \

INITIAL_OPTIONS_ACCORDING_BROADCAST = "1. My Info\n" \
               "3. Attendance Management\n" \
               "4. Payroll Management\n" \
               "5. Broadcast message over WhatsApp\n"\
               "6. Exit\n" \


INITIAL_OPTIONS = "1. My Info\n" \
               "3. Attendance Management\n" \
               "4. Payroll Management\n" \
               "5. Exit\n" \

askOrganizationForSendBrodCastMasg = "Which Organization would you like yo send?\n" \
                                    "1. Bidco Africa Limited (BAL)\n" \
                                    "2. Bidco Landolakes (BLOL)\n" \
                                    "3. Bidcoro Africa Limited (BCAL)\n" \
                                    "4. All of them\n" \

dicForCompanyCode = {"1":"BAL","2":"BLOL","3":"BCAL"}
nameForCompanyCode = {"1":"Bidco Africa Limited","2":"Bidco Landolakes","3":"Bidcoro Africa Limited"}

leave_dic = {'1': "%Annual%leave%", '2': "%Sick%leave%,%full%pay%", '3': "%Sick%leave%,%half%unpaid%",
                     '4': ["%Paternity%leave%","%Maternity%leave%"]}

CLASS1 = "ticket.open"
CLASS2 = "ticket.info"
CLASS3 = "ticket.closed"
CLASS4 = "ticket.reopen"
CLASS5 = "exit"
CLASS6 = "broadCastMsg"
CLASS_NOT_MATCH = "for.error"

more_than_asked_leave="Sorry, you don’t have requisite Leaves. Please select a number less than "

ERROR_MSG = "Oops, Some error occured, We are in process of rectifying this error asap."

EXIT_BYE = "Bye bye\n" \
           "Have a nice day!"

unable_to_find_name="“Sorry, I am not able to fetch anyone with that name. Can you please enter the colleague’s name again?”"

END_PROCESS = "Hope you were satisfied with our services, To further proceed please choose from the below options:"
WORNG_OPTION = "Please choose from the above correct options:"

header_1="You have selected My Info"
header_2 = "You have selected Leave Management"
header_3= " You have selected Attendance Management"
header_4="You have selected Payroll Management"

you_selected = "You have selected Get my Leaves"
leave_fetch = "Please wait as I fetch your leaves"
attendance_wait = "Please wait as I fetch your Attendance"
check_leaves_wait = "Please wait as I fetch your leave records"
selected_apply_for_leave= "You have selected: Apply for Leave. Please select from one of the options below"

full_pay_pending = "Sorry, you have Sick Leave, Full Pay available to be used. Kindly apply for Sick Leave, Full Pay"

##############################################################
anything_else="Is there anything else i can help you with? \n" \
                    "1. Back to Previous menu \n" \
                    "2. Back to Main menu \n" \
                    "3. Exit \n"
acknowledged = "Your request is successfully acknowledged, and a pdf copy has been sent to your email."

missing_manager = "Manager details are missing, please contact to HR"

missing_user_detail= "You have incomplete details, Please contact HR."

missing_higher_manager = "Higher Manager does not exist, please contact to HR"

missing_higher_manager_detail = "Higher Manager details are missing, please contact to HR"

sure_fetch= "Sure fetching your options..."
wait_fetch="Please Wait, fetching your options..."
description_2="You have selected:Leave Management"
description_option_select="Please select from one of the options from below"

info_menu= "1. View my details \n" \
           "2. View my manager's details \n" \
           "3. View my direct report details \n" \
           "4. Back to previous menu \n" \

description_menu_2="1. Get my Leaves \n" \
                "2. Check Leaves Taken \n" \
                "3. Apply for Leave \n" \
                "4. Team's Leave Approval List  \n" \
                "5. Approve Team's Leave\n" \
                "6. Check My Pending Leaves \n"\
                "7. Cancel My Leaves Applied \n"\
                "8. Back \n" \

ticket_type_header = "Please choose ticket type from below options:"

greater_than_one="Sorry, you have entered wrong input. Please select a number greater than 0"

category_header = "Please choose category from below options:"

selected_approve="You have selected:Get Approval List"

approve_leave_selected="You have selected: Team's Leave Approval List, Kindly find the list below:"
leave_pending="Below are your leaves which need to be approved by your manager"
approve_options="Please select from the options:\n" \
                "1.Fetch Employee Reporting on Leave\n" \
                "2.Fetch Employee list to Approve leaves\n" \

selected_check_leave='You have selected Check Leaves taken'
check_leaves_taken="1. Current Month \n" \
                "2. Last 30 days \n" \
                "3. Last 90 days \n" \
                "4. Last 180 days \n" \
                "5. Last 1 year \n" \
                "6. Back \n" \


how_many_days_leave_take = "How many days do you plan to take?"


date_ask = "Sure ,you have required Leave(s), can you please pick a start date in format of DD.MM.YYYY ?"
date_ask_lop = "You are applying for Unpaid Leave, Can you please pick a start date in format of DD.MM.YYYY for Unpaid Leave?"


thank_you = "Thank You"

thank_you_fetching = "Thank You, fetching details."

yes_confirm = """Please type "Y" for Yes or "N" for No"""

reason_leave = "Can you please provide your reason for leave?"
reason_LOP = "Can you please provide your reason for Unpaid Leave?"
personal_not_allowed = """Sorry, you can’t use words like personal while providing a reason for leave. Please provide an appropriate reason for leave"""
anything = "Is there anything else I can do for you?"
allowance_ask = "Would you like to apply for allownaces?"
task_allocate = "You are also required to allocate your responsibilities to your colleagues. Can you please write down the first responsibility?  An email for the same will be sent to whom responsibility has been allocated to and the 1st Manager.."
task_allocate_again = "You are required to allocate your responsibilities to your colleagues. Can you please write down the new responsibilities?"
allocate_to = "Who do you want to allocate to?"
task_allocate_record = "The responsibilities allocation has been recorded"

task_allocate_more = """Would you like to allocate more responsibilities? Please type "Y" for Yes or "N" for No. An email for the same will be sent to whom responsibility has been allocated to and the 1st Manager..."""
HR_get_back = "Also, HR shall get back to you regarding allowance. it shall be credited along with your payroll"
doctor_prescription = "Please attach the doctor's prescription or click a photo of the prescription"
sick_leave_reason_record = "Your sick leave for {} has been forwarded to your manager. Once approved you shall be notified."

info_leave_complete = "Hi {},\n" \
            "This is to inform you that your {} application will be over tommorow.\n" \
            "Kindly, apply for {} extension else an LOP shall be counted against you\n" \
            "To Apply for {} extension,kindly apply for another {}"


###################CAse:4 maternity_leave

proof_paternity="Please attach the proof for application of paternity leave. You can attach the document or click a photograph of the same"

###################GET APPROVE LIST case:1 FETCH EMPLOYEE REPORTING ON LEAVE


select_option_fetch_employe_2="Please select from the options\n" \
                                "1. Fetch Employee Reporting on Leave for today\n" \
                                "2. Fetch Employee list to Approve leaves for the week \n" \
                                "3. Back to the previous menu "
fetch_empl_toapprove="You have selected Employee list to approve leaves."

###################APPROVE ALL Leave selectively case:2

approve_leave="To approve the above, please select from the options below\n" \
            "1. Approve All\n" \
            "2. Choose from list\n" \
            "3. Back to Previous Menu "

choose_list="From the above Approval List, Please select the number you want to approve."

response_approve="Thank you for the response.\n" \
                "All the leave request have been approved"

response_approve_reject="Thank you for the response.\n" \
                        " Leave request has been Rejected"

select_option_fetch_employe="From the Approval List, Please select the number you want to approve.\n" \
                                "1. Fetch Employee Reporting on Leave for today\n" \
                                "2. Fetch Employee list to Approve leaves for the week \n" \
                                "3. Back to the previous menu "


select_number_approve="From the above Approval List, Please select the number you want to approve."


like_to_approve="Would you like to approve?\n" \
                "Please select from the options:\n" \
                "1. Approve\n" \
                "2. Reject\n" \
                "3. Exit\n" \

like_to_approve_2="Would you like to approve?\n" \
                "Please select from the options:\n" \
                "1. Approve\n" \
                "2. Reject\n" \
                "3. Back to the previous menu\n" \
                "4. Exit\n" \

response_approve_specific="Thank you for the response.\n" \
                "Leave has been approved"

response_reject_specific="Thank you for the response.\n" \
                "Leave has been rejected"


response_approve_all="Thank you for the response.\n" \
                "All the leave request have been approved"

approve_more="Would you like to continue with the remaining approvals? \n" \
                "1. Yes \n" \
                "2. No\n" \
                "3. Back to Previous Menu"
leave_option_wrong_input="Please choose from options between 1-4"

rewrite_reason="Please give a Genuine Reason. "

after_n_option="Thank you for the reply. Please choose from one of the options"

lop_y_n = "You have no more Annual leaves. Would you like to apply for Unpaid Leave?"
lop_all_y_n = "You have no more leaves. Would you like to apply for Unpaid Leave?"

rejection_reason = "Thank you for your response.\n" \
                " Can you please specify the reason for rejection? "

tell_employee = "We shall let know that his leave request has been rejected"

delete_leave = "Please Select the number you want to cancel"
###################CHECK ATENDANCE case:1(ATTENDANCE FOR YESTERDAY)


attendance_option = "Kindly select from the options below:\n" \
		        "1. Attendance for Yesterday \n" \
                "2. Attendance for Last 7 Days \n" \
                "3. Attendance for 30 Days \n" \
                "4. Attendance for 60 Days \n" \
                "5. Attendance for 90 Days \n" \
                "6. Back to Main menu "

AT1 = "You have selected: Attendance for Yesterday"
AT2 = "You have selected: Attendance for Last 7 Days"
AT3 = "You have selected: Attendance for 30 Days"
AT4 = "You have selected: Attendance for 60 Days"
AT5 = "You have selected: Attendance for 90 Days"
####DUMMY DAATA

contactToHR='Sorry, I am not able to process the request. Kindly contact HR.'
wait = "Wait, give us a moment"

###################PAYROLL MANNAGEMENT MENU case:1(GET PAY SLIP)

option_select_payroll = "Please select from one of the options from below. \n" \
                    "1.Fetch your payslip \n" \
                    "2.Back to Main menu "

you_selected_payroll = "You have selected. Fetch payslip"

enter_month = "Please Enter the month and the year in the format of MM/YYYY "

response_wait = "Thank you for the response. \n" \
              "Please Wait ..."

payslip_email = "The  payslip for the month of {} has been sent to your email"


###################P#####################################################


GET_TICKET_NO = "Please Enter the Ticket Number:"

TICKET_CLOSE_HEADER = "Do you want to close this ticket?"

REOPEN_RESOLVED = "The ticket is in resolved state."

REOPEN_CHECK_MSG = "Do you want to Reopen this incident?"

YES_NO  = "1. Yes\n" \
          "2. No"

TICKET_CLOSE_SUCC = "Your Ticket is Closed successfully."

comment = "Please enter comment"

REOPEN_TICKET_SUCCESS = "Your Ticket is Reopen successfully."

CUSTOMER_WAITING_MSG = "Do you want to submit your query?"

ADD_COMMENT_SUCCESS = "Comment Added successfully."



MANAGERCLASS1 = "apporveOrRejectByManager"
MANAGERCLASS2 = "approvedByManagerWithoutMail"
MANAGERCLASS3 = "ticket.closed"

approve_more_for_manager="Would you like to continue with the remaining approvals? \n" \
                "1. Yes \n" \
                "2. No\n" \

date_back = "You can not apply leave for previous date"

substituteMsg = "You are currently substituted. The task is handled by {0}. So, you would not be able to approve/reject employee leave requests"

taskAllocationEmailBody = """
Dear {0},

        This is to inform you that Employee name is {1} and ID no. is {2} is going on leave from {3} to {4}
In their absence the following task has been allocated to you:

Task: {5}

Regards
Aria 

"""

leaveApplyEmailBody = """
Dear {0},
    
    Your leave request for {1} has been forwarded to your manager. Once approved you shall be intimated.

Regards
Aria
"""

leaveApproveEmailBody = """
Dear {0}.

    Your leave from date {1}  to date {2}  is approved.
    
Regards
Aria 
"""

leaveRejectEmailBody = """
Dear {0}.

    Your leave from date {1}  to date {2}  is rejected with reason {3}.

Regards
Aria 
"""

attendanceEmailBody = """
Dear {0},
 
    As per your request on Aria, please find attached PDF for your attendance record of {1}.
 
Regards
Aria
 

"""

zeroLeaveMessage = "You don't have {0} available."
allLeavesZero = "You don't have any leave"