

from webwhatsapi import WhatsAPIDriver
from whatsapp import messages
from whatsapp import messages as CONFIG_MESS
# from lib.service_now import ServiceNowCrud
from whatsapp import temp_data
from whatsapp.context import Context
import os
regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
import pdfkit

import time


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))



path_wkthmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)



driver = WhatsAPIDriver(loadstyles=True)
print("Waiting for QR")
driver.wait_for_login()
print("Bot started")




                                   
def run():
    print("Waiting for new messages...")
    while True:
        for contact in driver.get_unread():
            # print ("I am in for loop")
            for message in contact.messages:
                messageType = message.type
                print ("message =====>", messageType)
                userId = message.chat_id
                userId = str(userId['_serialized'])

            
                if message.type == 'chat' and message.content.lower() in ['bye','hi','hello','Hi','exit']:
                    print('hello amit ')
                    driver.send_message_to_id(userId, "Hello ")
                    driver.send_message_to_id(userId, "My name is Rasa Chatbot")

                    
                else:
                    print ("userId =====>", userId)
                    userName = "User" #message.sender.get_safe_name()

                           


if __name__ == '__main__':
    run()

